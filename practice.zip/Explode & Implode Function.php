<?php
	session_start();
	include 'include/header.php';
	////setcookie('visited',"",time()-3600);  ///cookies deleted
?>
	
    <section class="maincontent">
  <hr/>
	PHP Filters
	<span style="float:right"> 
	<?php
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Time :".date ("h:i:sa")."<br/>";
?>
	</span>
	<hr/>
	
	 <?php 
		$mystr = "We learning PHP";
		$str = explode(" ",$mystr);   ////1st ta re deli meter bole ..
		echo $str[2];
		
		/////tring ke Array te nite explode function use kori
		/////2 ta pera meter 1st ta deli meter 2nd ta source string .
		
	
		$myst = array("We","are","Learning", "Php");
		echo implode(" ",$myst);
		////implode diye array ke string banano hoi 
		
	?>
	




    </section>


<?php
	include 'include/footer.php';

?>