<?php
	include 'include/header.php';
?>
	
	<hr/>
	PHP File Create
	<span style="float:right"> 
	<?php
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Time :".date ("h:i:sa")."<br/>";
?>
	</span>
	<hr/>

    <section class="maincontent">
    <?php
		$createfile= fopen("file/new.txt","w");
		$one="Khaled Saifullah Sadi\n";
		fwrite($createfile,$one);
		
		$two="Dept OF CSE\n";
		fwrite($createfile,$two);
		
		fclose($createfile);
		
	?>
	
	
    </section>


<?php
	include 'include/footer.php';

?>