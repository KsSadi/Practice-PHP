<?php
	session_start();
	include 'include/header.php';
	////setcookie('visited',"",time()-3600);  ///cookies deleted
?>
	
    <section class="maincontent">
  <hr/>
	PHP Cookies
	<span style="float:right"> 
	<?php
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Time :".date ("h:i:sa")."<br/>";
?>
	</span>
	<hr/>
	 <?php
	 if(!isset($_COOKIE['visit'])){
		 setcookie("Visited","1",time()+86400,"/") or die("Could Not Set Cookie");
		echo"This is your first visit in this website.";
	 } else{
		 echo "You are old visitor.";
	 }
		 
		 
		///setcookie(name,value,expire,path,domain,secure,httponly);
		
	 
	 ?>
	
	
	
	
   
   
   
    </section>


<?php
	include 'include/footer.php';

?>