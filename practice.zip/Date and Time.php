<?php 
$fonts="Arial";
$footer="Priyojon.com.bd";
$header="PHP Fundamental";
$fontclr="#fff";
$bg="#ddd";
$break="</br>";
?>
<!doctype html>
<html>
<title> PHP Syntex</title>
<style>
    .phpcoading{width: 900px; margin: 0 auto;background:<?php echo $bg;?>;min-height:400px;}
    .headeroption ,.footeroption {background:#444; color:#fff;text-align:center;padding:20px;}
    .maincontent{min-height:400px;padding:20px;}
	.headeroption h2, .footeroption h2{margin:0} p{margin:0}
	body{font-family:<?php echo $fonts;?>}
	
</style>
<body>

<section class="phpcoading">
    <section class="headeroption">
        <h2><?php echo $header;?></h2>
    </section>
	
	<hr/>
	PHP Date And Table
	<span style="float:right"> 
	<?php
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Time :".date ("h:i:sa")."<br/>";
?>
	</span>
	<hr/>

    <section class="maincontent">
    <?php
		//date(format, timestamp);  structure
		echo "Today is :".date ("D/M/Y")."<br/>";
		echo "Today is :".date ("l")."<br/>"; //Day 
		echo "Today is :".date ("h:i:sa")."<br/>"; //Defult Time
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Today is :".date ("h:i:sa")."<br/>"; //Our Time
		echo date_default_timezone_get();
		echo "Today is :".date ("l")."<br/>";
		
	///https://www.php.net/manual/en/function.date
	?>
	
	
    </section>


    <section class="footeroption">
	<p>&copy; <?php echo date("Y"); ?> By Sadi </p>
    <h2><?php echo $footer;?></h2>
    </section>

</section>
</body>





</html>