<?php
	include 'include/header.php';
?>
	
	<hr/>
	PHP File Upload
	<span style="float:right"> 
	<?php
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Time :".date ("h:i:sa")."<br/>";
?>
	</span>
	<hr/>
	<?php
		if(isset($_FILES['image'])){
			$filename=$_FILES['image']['name'];
			$filetmp=$_FILES['image']['tmp_name'];
			move_uploaded_file($filetmp,"file/".$filename);
			echo "Image Upload Successfully ! ";
		}
	
	?>

    <section class="maincontent">
   <form method="POST" action="" enctype="multipart/form-data">
	<input type="file" name="image"/>
	<input type="submit" value="Submit"/>
   </form>
    </section>


<?php
	include 'include/footer.php';

?>