<?php
	include 'include/header.php';
?>
	
	<hr/>
	PHP File Handling
	<span style="float:right"> 
	<?php
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Time :".date ("h:i:sa")."<br/>";
?>
	</span>
	<hr/>

    <section class="maincontent">
    <?php
		$ourfile= fopen("file/text.txt","r") or die("File Not Found !"); // open
		//echo fread($ourfile,filesize("file/text.txt")); ///read
		//echo fgets($ourfile,filesize("file/text.txt")); for 1st line output
		//echo fgetc($ourfile); for 1st letter output
		while(!feof($ourfile)){
			echo fgets($ourfile)."<br/>";
		}  ///line by line all output
		fclose($ourfile); ///close			
	?>
	
	
    </section>


<?php
	include 'include/footer.php';

?>