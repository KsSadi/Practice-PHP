<?php
	$messege= $_GET['msg'];
	$word =$_GET['text'];
	
	echo "First Text : ".$messege;
	echo "<br/>";
	echo "Second Text :".$word;
?>