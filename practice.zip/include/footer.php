

    <section class="footeroption">
	<?php include'include/date.php';
	//require'include/date.php'; -je khane missing oi khan ei stop ar kichu show korbe na .
	?>
    <h2><?php echo $footer;?></h2>
    </section>

</section>
</body>





</html>