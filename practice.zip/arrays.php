<?php 
$fonts="Arial";
$footer="Priyojon.com.bd";
$header="PHP Fundamental";
$fontclr="#fff";
$bg="#ddd";
$break="</br>";
?>
<!doctype html>
<html>
<title> PHP Array</title>
<style>
    .phpcoading{width: 900px; margin: 0 auto;background:<?php echo $bg;?>;min-height:400px;}
    .headeroption ,.footeroption {background:#444; color:#fff;text-align:center;padding:20px;}
    .maincontent{min-height:400px;padding:20px;}
	.headeroption h2, .footeroption h2{margin:0}
	body{font-family:<?php echo $fonts;?>}

</style>
<body>

<section class="phpcoading">
    <section class="headeroption">
        <h2><?php echo $header;?></h2>
    </section>

    <section class="maincontent">
    <?php
	////Index Array
	$x=array(5,3,2,6,5,8,9);
	
	echo $x[2];
	echo"<br/>";
	echo count($x); ///For Show the aray leanth
	$length=count($x);
	echo"<br/>";
	for($i=0; $i<$length;$i++)
	{
		echo $x[$i];
		echo"<br/>";
	}
	
	$age= array("karim"=>"25", "Rahim"=>"20","Mamun"=>"28");
	
	echo count($age);
	
	/*$age["Korim"] = "25";
	$age["Rahim"] = "20";
	$age["Mamun"] = "28";
	*/
	
	foreach ($age as $y => $value)
	{
		echo "key = ".$y. ", Value=".$value. "<br/>";
	}
	
	//Multidimentional array
	
	$cars = array(

	array("BMW",15,50),
	array("Volvo",20,5),
	array("Saab",25,30)
	);
	echo $cars[1][0];
	
	for($row=0; $row <3; $row++){
		echo"<p>Row Number $row</p>";
		echo "<ul>";
		for($col=0; $col<3;$col++){
			echo"<li>".$cars[$row][$col]."</li>";
			
		}
		
		echo "</ul>";
	}
	
    ?>
		
	
    </section>


    <section class="footeroption">
    <h2><?php echo $footer;?></h2>
    </section>

</section>
</body>





</html>