<?php
	include 'include/header.php';
?>
	
	<hr/>
	PHP File Handling
	<span style="float:right"> 
	<?php
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Time :".date ("h:i:sa")."<br/>";
?>
	</span>
	<hr/>

    <section class="maincontent">
    <?php
		echo readfile("file/text.txt");
		
		
	?>
	
	
    </section>


<?php
	include 'include/footer.php';

?>