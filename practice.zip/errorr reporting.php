<?php
	session_start();
	include 'include/header.php';
	////setcookie('visited',"",time()-3600);  ///cookies deleted
?>
	
    <section class="maincontent">
  <hr/>
	PHP Filters
	<span style="float:right"> 
	<?php
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Time :".date ("h:i:sa")."<br/>";
?>
	</span>
	<hr/>
	 <?php
		
		error_reporting(E_ERROR | E_WARNING | E_PARSE |E_NOTICE);		
		$price = 45;
		if($price==45){
			echo"The Price is : $price";
		}else {
			echo"The Price is Not 45 ";
		}
		
		//////PHP Exception.
		
		function numCheck($num){
			if($num!==5){
				throw new Exception("Please Enter Number 5");
			}
			return true;
			
		}
		try {
			numCheck(5);
			echo "If You See This , The Number is 1 or below";
		}
		catch(Exception $e){
			echo "Error: ".$e->getMessage();
		}
	 ?>
	
	
	
	
   
   
   
    </section>


<?php
	include 'include/footer.php';

?>