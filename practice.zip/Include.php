<?php
	include 'include/header.php';
?>
	
	<hr/>
	PHP Date And Table
	<span style="float:right"> 
	<?php
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Time :".date ("h:i:sa")."<br/>";
?>
	</span>
	<hr/>

    <section class="maincontent">
    <?php
		
	?>
	
	
    </section>


<?php
	include 'include/footer.php';

?>