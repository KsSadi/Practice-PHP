<?php
	session_start();
	include 'include/header.php';
	////setcookie('visited',"",time()-3600);  ///cookies deleted
?>
	
    <section class="maincontent">
  <hr/>
	PHP Filters
	<span style="float:right"> 
	<?php
		date_default_timezone_set('Asia/Dhaka'); //TimeZone
		echo "Time :".date ("h:i:sa")."<br/>";
?>
	</span>
	<hr/>
	 <?php
		$str = "<h2>I am Learning PHP.</h2>";
		$newstr = filter_var($str,FILTER_SANITIZE_STRING); ///remove html tag
		echo $newstr;
		/////INT
		$int =50.5;
		if(filter_var($int,FILTER_VALIDATE_INT)){ //check int
			echo "This is INT";
			
		}else {
			echo"This is not integer";
		}
		///////IP
		$ip ="127.0.0.1";
		if(filter_var($ip,FILTER_VALIDATE_IP)){ //check int
			echo "$ip  is valid IP";
			
		}else {
			echo"$ip is Invalid";
		}
		////////Mail
		$mail ="sadi@gmail.com";
		if(filter_var($mail,FILTER_VALIDATE_EMAIL)){ //check int
			echo "$mail  is valid";
			
		}else {
			echo"$mail is Invalid";
		}
		////////URL
		$url ="http://www.sadigmail.com";
		if(filter_var($url,FILTER_VALIDATE_URL)){ //check int
			echo "$url  is valid";
			
		}else {
			echo"$url is Invalid";
		}
	 ?>
	
	<?php
	echo "<br/>";
		$intnum=300;
		$min = 1;
		$max = 200;
		if(filter_var($intnum,FILTER_VALIDATE_INT,array("options" => array("min_range" => $min,"max_range" => $max)))){
			echo "It is not valid";
		}else{
			echo"It is Not Valid";
		}
		echo "<br/>";
		
		$url = "http://google.com/index.html?q=123";
		
		if(filter_var($url,FILTER_VALIDATE_URL,FILTER_FLAG_QUERY_REQUIRED)){
			echo "This URL valid";
		}else{
			echo"It has not query";
		}
	
	
	?>
	
	
   
   
   
    </section>


<?php
	include 'include/footer.php';

?>